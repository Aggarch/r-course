library(tidyverse)
library(cluster)

telecom <- read_csv("telecomunicaciones.csv")

telecom %>% glimpse()

datos_segmentacion <- telecom %>% 
  mutate_if(is.character, as.factor) %>% 
  mutate(contrato = factor(contrato, 
                           levels = c("mes_a_mes", "un_anio", "dos_anios"),
                           ordered = TRUE))

set.seed(1)

datos_filtrados <- 
  datos_segmentacion %>% 
  select(permanencia, cargo_mensual, contrato, adulto_mayor) %>% 
  sample_n(1500) %>% 
  mutate(adulto_mayor = as.factor(adulto_mayor))


matriz_distancia <- daisy(datos_filtrados)

matriz_distancia

resultado <- pam(x = matriz_distancia, k = 4)

resultado$silinfo

pam_function <- function(matriz, centros){
  
  resultado <- pam(x = matriz, k = centros)
  return(resultado$silinfo$avg.width)
}

tibble(centros = 2L:10L) %>% 
  mutate(silueta = map_dbl(.x = centros, .f = pam_function, matriz = matriz_distancia)) %>% 
  ggplot(aes(x = as.factor(centros), y = silueta))+
  geom_point()+
  geom_line(aes(group = 1))+
  labs(title = "Numero de Segmentos Optimos")

jerarquico <- hclust(matriz_distancia, method = "average")
plot(jerarquico, labels = F, hang = -1)


datos_filttrados %>% 
  mutate(segmento = resultado$clustering) %>% 
  group_by(segmento) %>% 
  summarise(permanencia = mean(permanencia), cargo_mensual = mean(cargo_mensual))

resultado$clustering





