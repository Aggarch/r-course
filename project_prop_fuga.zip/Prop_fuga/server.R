
library(shiny)
library(tidyverse)
library(kableExtra)

shinyServer(function(input, output) {

  modelo <- read_rds("modelo.rds")      
  
  output$tabla <- renderText({
    tibble(Caracteristicas = c("Cedula", "Nombre"),
           ` ` = c(input$cedula, input$nombre)) %>% 
      kable() %>% 
      kable_styling(full_width = F)
    
  })
  output$probabilidad_box <- renderValueBox({
    
    datos <- tibble(contrato = input$contrato,
                    permanencia = as.numeric(input$permanencia),
                    seguridad_en_linea = input$seg_linea,
                    metodo_pago = input$metodo,
                    cargo_mensual = as.numeric(input$cargo)
                    )
    
    datos_modelo <- modelo %>% 
      predict(datos, "prob") %>% 
      mutate(.pred_Si = ifelse(input$cedula == "",0, .pred_Si)) %>% 
      mutate(color = case_when(
        between(.pred_Si, 0, 0.3) ~ "green",
        between(.pred_Si, 0.3, 0.6) ~ "orange",
        between(.pred_Si, 0.6, 1)~ "red"
      ))
    
    probabilidad <- datos_modelo %>% pull(.pred_Si) 
    color_caja <- datos_modelo %>% pull(color)
    
    
    valueBox(value = scales::percent(probabilidad), icon = icon("address-card"),
             color = color_caja, subtitle = "Probabilidad Fuga")
  })
  
})
