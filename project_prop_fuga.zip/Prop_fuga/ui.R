library(shiny)
library(shinydashboard)
library(shinythemes)

dashboardPage(
    dashboardHeader(title = "Modelo Fuga"),
    dashboardSidebar(
        textInput(inputId = "cedula",
                  label = "Cedula Cliente", 
                  placeholder = " digitar..."),
        textInput(inputId = "nombre", label = "Nombre"),
        selectInput(inputId = "metodo", label = "Metodo de Pago",
                    choices = c("debito_automatico (aut)",
                                "pago_electronico",
                                "pago_fisico",
                                "tarjeta_de_credito(aut)")),
        selectInput(inputId = "contrato", label = "Contrato",
                    choices = c("mes_a_mes",
                                "un_anio",
                                "dos_anios")),
        textInput(inputId = "permanencia", label = "Permanencia", value = 0),
        numericInput(inputId = "cargo", label = "Cargo Mensual", value = 0),
        selectInput(inputId = "seg_linea", label = "Seguridad en Linea",
                    choices = c("Si", "No", "Sin servicio internet")),
        br(),
        submitButton(text = "Generar", icon = icon("search"))
        
        
        
    ),
    dashboardBody(
        box(width = 7,
            title = "Datos del Cliente", 
            htmlOutput("tabla")
            ),
        box(width = 5,
            title = "Nivel de Riesgo de Fuga",
            valueBoxOutput(width = 12, "probabilidad_box"))
    )
)
